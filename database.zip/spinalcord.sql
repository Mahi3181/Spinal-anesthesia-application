-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2024 at 07:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spinalcord`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor_details`
--

CREATE TABLE `doctor_details` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `designation` text NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_details`
--

INSERT INTO `doctor_details` (`id`, `name`, `email`, `password`, `designation`, `img`) VALUES
(1, 'mahi6', '23@gmail.com', 'mmm', 'mmm', '');

-- --------------------------------------------------------

--
-- Table structure for table `patient_details`
--

CREATE TABLE `patient_details` (
  `id` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Age` text NOT NULL,
  `Gender` text NOT NULL,
  `Diagnosis` text NOT NULL,
  `image` text NOT NULL,
  `TIMESTAMP` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_details`
--

INSERT INTO `patient_details` (`id`, `Name`, `Age`, `Gender`, `Diagnosis`, `image`, `TIMESTAMP`) VALUES
(16, 'nara', '55', 'M', 'haa', '', '2024-05-07 05:18:43'),
(18, 'mqm', '59', 'M', 'qqhaa', '', '2024-05-07 05:18:43'),
(27, 'd', '5', 'd', 'd', '', '2024-05-07 05:18:43'),
(28, 'dh DJ', '22', 'ggg', 'ggg', '', '2024-05-07 05:18:43'),
(29, 'dh DJ', '22', 'ggg', 'ggg', '', '2024-05-07 05:18:43'),
(32, 'vahgy', '59', 'M', 'qqhaa', 'image/Screenshot 2024-02-20 103405.png', '2024-05-07 05:18:43'),
(33, 'fi', '8', 'fh', 'Gau', 'image/image.jpg', '2024-05-07 05:18:43'),
(34, 'jshz', '9797', 'bzbz', 'jzjz', 'image/image.jpg', '2024-05-07 05:18:43'),
(35, 'bs', '659', 'bxb', 'nxn', 'image/image.jpg', '2024-05-07 05:18:43'),
(36, 'bs', '659', 'bxb', 'nxn', 'image/image.jpg', '2024-05-07 05:18:43'),
(37, 'GD', '55', 'haa', 'good', 'image/image.jpg', '2024-05-07 05:18:43'),
(38, 'ttt', '55', 'ttt', 'ttt', 'image/image.jpg', '2024-05-07 05:18:43'),
(39, 'vahgy', '59', 'M', 'qqhaa', 'image/Screenshot 2024-02-05 114205.png', '2024-05-07 05:18:43'),
(40, 'vahgy', '59', 'M', 'qqhaa', 'image/Screenshot 2024-02-05 114205.png', '2024-05-07 05:18:43'),
(41, 'dh', '22', 'sh', 'GK', 'image/image.jpg', '2024-05-07 05:18:43'),
(42, 'raj', '22', 'sh', 'GK', 'image/image.jpg', '2024-05-07 05:18:43'),
(43, 'fi', '55', 'fh', 'gan', 'image/image.jpg', '2024-05-07 05:18:43'),
(44, 'kkk', '66', 'jhj', 'hh', 'image/image.jpg', '2024-05-07 05:18:43'),
(45, 'jsj', '976', 'nzj', 'jzj', 'image/image.jpg', '2024-05-07 05:18:43'),
(46, 'hmm', '22', 'male', 'FB', 'image/image.jpg', '2024-05-07 05:18:43'),
(47, 'mc', '5', 'GD', 'haa', 'image/image.jpg', '2024-05-07 05:18:43'),
(49, 'sarada', '20', 'female', 'fever', 'image/image.jpg', '2024-05-07 05:18:43'),
(52, 'mahi', '55', 'mp', 'hag', 'image/image2.png', '2024-05-07 05:18:43'),
(54, 'Error: null', '', '', '', 'image/image4.png', '2024-05-07 05:18:43'),
(56, 'mah', '66', 'CVhh', 'FB', 'image/image2.jpg', '2024-05-07 05:18:43'),
(57, 'dh', '6', 'CV', 'FB', 'image/image3.jpg', '2024-05-07 05:18:43'),
(58, 'mah', '55', 'male', 'ok', 'image/image4.jpg', '2024-05-07 05:18:43'),
(59, 'jhg', '55', 'male', 'jhg', 'image/image5.jpg', '2024-05-07 05:18:43'),
(61, 'dn', '65', 'hx', 'bz', 'image/image6.jpg', '2024-05-07 05:18:43'),
(62, 'mahi', '22', 'male', 'mbb', 'image/image7.jpg', '2024-05-07 05:18:43'),
(63, 'maheshk', '515', 'malee', 'mbbss', 'image/image8.jpg', '2024-05-07 05:18:43'),
(64, 'kamai', '5', 'mal', 'mbb', 'image/image9.jpg', '2024-05-07 05:18:43'),
(66, 'may', '55', 'male', 'mbbs', 'image/image11.jpg', '2024-05-07 05:18:43'),
(67, 'mah', '66', 'male', 'bsbsb', 'image/image12.jpg', '2024-05-07 05:18:43'),
(68, 'kk', '22', 'hh', 'bzbz', 'image/image13.jpg', '2024-05-07 05:18:43'),
(69, 'ajay', '55', 'male', 'kk', 'image/image14.jpg', '2024-05-07 05:18:43'),
(70, 'ghjk', '45', 'sdfg', 'dfg', 'image/192311070-Title-1.png', '2024-05-07 05:18:43'),
(71, 'ne', '88', 'ml', 'jkkj', 'image/DB7C5667-1474-4D09-8440-1AC6547A89E3.jpg', '2024-05-07 05:18:43'),
(72, 'buy', '66', 'male', 'll', 'image/032FE907-CFD4-4AFF-A3EE-70A28343526C.jpg', '2024-05-07 05:18:43'),
(73, 'lo', '9', 'l', 'l', 'image/FBE904BA-18D1-4A61-9C16-D38CB45F4FA5.jpg', '2024-05-07 05:28:44');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `id` int(11) NOT NULL,
  `result` text NOT NULL,
  `interpretation` text NOT NULL,
  `submission_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `result`, `interpretation`, `submission_datetime`) VALUES
(11, '20', 'medium risk for hypotension', '2024-02-26 04:05:15'),
(11, '18', 'medium risk for hypotension', '2024-02-26 04:05:27'),
(11, '23', 'high risk for hypotension', '2024-02-26 04:24:25'),
(12, '23', 'high risk for hypotension', '2024-02-26 04:28:36'),
(12, '21', 'high risk for hypotension', '2024-02-26 04:28:57'),
(11, '24', 'high risk for hypotension', '2024-02-26 05:18:37'),
(11, '27', ' very high risk for hypotension', '2024-02-26 05:49:13'),
(11, '22', 'high risk for hypotension', '2024-02-26 06:09:23'),
(12, '14', 'ffff', '2024-02-29 05:06:44'),
(15, '23', 'high risk for hypotension', '2024-02-29 05:12:03'),
(15, '16', 'medium risk for hypotension', '2024-02-29 05:12:36'),
(15, '0', ' very high risk for hypotension', '2024-02-29 05:14:21'),
(15, '0', ' very high risk for hypotension', '2024-02-29 05:20:03'),
(15, '0', ' very high risk for hypotension', '2024-02-29 05:20:27'),
(15, '0', ' very high risk for hypotension', '2024-02-29 05:20:29'),
(15, '4', 'L0w risk for hypotension', '2024-02-29 05:20:54'),
(15, '0', ' very high risk for hypotension', '2024-02-29 05:20:58'),
(15, '0', ' very high risk for hypotension', '2024-02-29 05:21:00'),
(15, '2', 'L0w risk for hypotension', '2024-02-29 05:26:12'),
(15, '2', 'L0w risk for hypotension', '2024-02-29 05:26:37'),
(15, '0', ' very high risk for hypotension', '2024-02-29 05:36:59'),
(15, '10', 'L0w risk for hypotension', '2024-02-29 05:37:51'),
(16, '4', 'L0w risk for hypotension', '2024-02-29 05:39:16'),
(16, '0', ' very high risk for hypotension', '2024-02-29 05:40:20'),
(16, '2', 'L0w risk for hypotension', '2024-02-29 05:42:07'),
(15, '10', 'L0w risk for hypotension', '2024-02-29 05:44:22'),
(15, '14', 'medium risk for hypotension', '2024-02-29 05:57:19'),
(15, '4', 'L0w risk for hypotension', '2024-02-29 05:57:33'),
(16, '4', 'L0w risk for hypotension', '2024-02-29 05:58:16'),
(16, '4', 'L0w risk for hypotension', '2024-02-29 05:58:39'),
(15, '4', 'L0w risk for hypotension', '2024-02-29 05:59:51'),
(15, '4', 'L0w risk for hypotension', '2024-02-29 06:00:28'),
(16, '8', 'L0w risk for hypotension', '2024-02-29 06:01:43'),
(16, '0', ' very high risk for hypotension', '2024-02-29 06:02:17'),
(15, '10', 'L0w risk for hypotension', '2024-02-29 06:08:26'),
(15, '10', 'L0w risk for hypotension', '2024-02-29 06:13:53'),
(15, '8', 'L0w risk for hypotension', '2024-02-29 06:14:45'),
(15, '4', 'L0w risk for hypotension', '2024-02-29 06:15:21'),
(15, '4', 'L0w risk for hypotension', '2024-02-29 06:16:58'),
(15, '8', 'L0w risk for hypotension', '2024-02-29 22:58:01'),
(16, '8', 'L0w risk for hypotension', '2024-02-29 23:03:20'),
(16, '10', 'L0w risk for hypotension', '2024-02-29 23:03:28'),
(15, '4', 'L0w risk for hypotension', '2024-03-05 22:39:16'),
(15, '8', 'L0w risk for hypotension', '2024-03-05 22:50:39'),
(16, '4', 'L0w risk for hypotension', '2024-03-10 22:31:53'),
(18, '4', 'L0w risk for hypotension', '2024-03-12 03:52:00'),
(16, '4', 'L0w risk for hypotension', '2024-03-12 03:52:20'),
(27, '4', 'L0w risk for hypotension', '2024-03-12 03:55:50'),
(26, '4', 'L0w risk for hypotension', '2024-03-12 03:58:18'),
(26, '8', 'L0w risk for hypotension', '2024-03-12 03:58:29'),
(27, '8', 'L0w risk for hypotension', '2024-03-12 03:59:24'),
(31, '6', 'L0w risk for hypotension', '2024-03-12 04:04:15'),
(30, '2', 'L0w risk for hypotension', '2024-03-12 04:05:27'),
(30, '4', 'L0w risk for hypotension', '2024-03-12 04:06:02'),
(15, '4', 'L0w risk for hypotension', '2024-03-12 22:20:42'),
(15, '4', 'L0w risk for hypotension', '2024-03-12 22:23:21'),
(15, '6', 'L0w risk for hypotension', '2024-03-12 22:27:01'),
(15, '2', 'L0w risk for hypotension', '2024-03-12 22:31:01'),
(15, '6', 'L0w risk for hypotension', '2024-03-12 22:48:57'),
(26, '8', 'L0w risk for hypotension', '2024-03-12 22:50:04'),
(29, '8', 'L0w risk for hypotension', '2024-03-12 23:03:46'),
(26, '4', 'L0w risk for hypotension', '2024-03-12 23:12:16'),
(28, '4', 'L0w risk for hypotension', '2024-03-12 23:13:51'),
(28, '4', 'L0w risk for hypotension', '2024-03-12 23:13:54'),
(28, '8', 'L0w risk for hypotension', '2024-03-13 05:26:12'),
(28, '8', 'L0w risk for hypotension', '2024-03-13 05:26:16'),
(28, '10', 'L0w risk for hypotension', '2024-03-13 05:26:20'),
(28, '26', ' very high risk for hypotension', '2024-03-13 22:33:52'),
(34, '4', 'L0w risk for hypotension', '2024-03-14 01:23:40'),
(38, '8', 'L0w risk for hypotension', '2024-03-14 05:14:32'),
(42, '4', 'L0w risk for hypotension', '2024-03-20 22:52:24'),
(50, '4', 'L0w risk for hypotension', '2024-03-25 01:28:52'),
(16, '10', 'L0w risk for hypotension', '2024-03-25 01:29:21'),
(50, '8', 'L0w risk for hypotension', '2024-03-25 01:29:35'),
(52, '8', 'L0w risk for hypotension', '2024-03-25 01:42:42'),
(36, '8', 'L0w risk for hypotension', '2024-03-25 02:19:43'),
(16, '6', 'L0w risk for hypotension', '2024-03-28 22:56:07'),
(16, '8', 'L0w risk for hypotension', '2024-03-28 22:56:14'),
(56, '4', 'L0w risk for hypotension', '2024-03-28 23:02:10'),
(56, '8', 'L0w risk for hypotension', '2024-03-29 02:00:16'),
(56, '8', 'L0w risk for hypotension', '2024-03-29 02:00:29'),
(56, '8', 'L0w risk for hypotension', '2024-03-29 02:00:30'),
(56, '8', 'L0w risk for hypotension', '2024-03-29 02:00:37'),
(56, '8', 'L0w risk for hypotension', '2024-03-29 02:00:48'),
(47, '0', ' very high risk for hypotension', '2024-03-29 02:01:06'),
(47, '0', ' very high risk for hypotension', '2024-03-29 02:01:38'),
(47, '0', ' very high risk for hypotension', '2024-03-29 02:01:53'),
(56, '0', ' very high risk for hypotension', '2024-03-29 02:02:17'),
(56, '0', ' very high risk for hypotension', '2024-03-29 02:03:59'),
(57, '0', ' very high risk for hypotension', '2024-03-29 02:08:33'),
(57, '0', ' very high risk for hypotension', '2024-03-29 02:08:44'),
(56, '2', 'L0w risk for hypotension', '2024-03-29 02:09:10'),
(56, '2', 'L0w risk for hypotension', '2024-03-29 02:09:24'),
(57, '0', ' very high risk for hypotension', '2024-03-29 03:39:36'),
(57, '0', ' very high risk for hypotension', '2024-03-29 03:39:46'),
(57, '0', ' very high risk for hypotension', '2024-03-29 03:39:54'),
(58, '0', ' very high risk for hypotension', '2024-03-29 03:45:14'),
(58, '4', 'L0w risk for hypotension', '2024-03-29 03:52:51'),
(58, '0', ' very high risk for hypotension', '2024-03-29 03:55:16'),
(58, '0', ' very high risk for hypotension', '2024-03-29 03:55:35'),
(58, '0', ' very high risk for hypotension', '2024-03-29 04:00:12'),
(58, '0', ' very high risk for hypotension', '2024-03-29 04:01:37'),
(58, '0', ' very high risk for hypotension', '2024-03-29 04:01:46'),
(58, '0', ' very high risk for hypotension', '2024-03-29 04:03:32'),
(58, '0', ' very high risk for hypotension', '2024-03-29 04:04:00'),
(58, '4', 'L0w risk for hypotension', '2024-03-29 04:04:20'),
(58, '4', 'L0w risk for hypotension', '2024-03-29 04:04:50'),
(58, '0', ' very high risk for hypotension', '2024-03-29 04:05:02'),
(58, '4', 'L0w risk for hypotension', '2024-03-29 04:07:50'),
(58, '4', 'L0w risk for hypotension', '2024-03-29 04:11:36'),
(58, '0', ' very high risk for hypotension', '2024-03-29 04:11:45'),
(58, '2', 'L0w risk for hypotension', '2024-03-29 04:11:57'),
(58, '4', 'L0w risk for hypotension', '2024-03-29 04:16:56'),
(57, '2', 'L0w risk for hypotension', '2024-03-29 04:18:32'),
(57, '0', ' very high risk for hypotension', '2024-03-29 04:18:49'),
(60, '20', 'medium risk for hypotension', '2024-04-01 01:16:14'),
(60, '24', 'high risk for hypotension', '2024-04-01 01:16:28'),
(60, '28', ' very high risk for hypotension', '2024-04-01 01:16:51'),
(60, '28', ' very high risk for hypotension', '2024-04-01 01:17:10'),
(60, '24', 'high risk for hypotension', '2024-04-01 01:17:30'),
(63, '28', ' very high risk for hypotension', '2024-04-01 01:24:26'),
(63, '28', ' very high risk for hypotension', '2024-04-01 01:24:49'),
(63, '26', ' very high risk for hypotension', '2024-04-01 01:25:00'),
(64, '8', 'L0w risk for hypotension', '2024-05-04 01:00:03'),
(64, '8', 'L0w risk for hypotension', '2024-05-04 01:05:06'),
(65, '24', 'high risk for hypotension', '2024-05-05 03:48:52'),
(69, '16', 'medium risk for hypotension', '2024-05-07 00:06:47'),
(69, '2', 'L0w risk for hypotension', '2024-05-07 00:08:39'),
(69, '0', ' very high risk for hypotension', '2024-05-07 00:10:47'),
(64, '18', 'Medium Risk For Hypotention', '2024-05-07 01:08:34'),
(72, '8', 'Low Risk For Hypotention', '2024-05-07 01:13:06'),
(36, '22', 'High Risk For Hypotention', '2024-05-07 01:24:17'),
(18, '22', 'High Risk For Hypotention', '2024-05-07 01:26:33'),
(18, '18', 'Medium Risk For Hypotention', '2024-05-07 01:29:45'),
(18, '16', 'Medium Risk For Hypotention', '2024-05-07 05:12:29'),
(73, '20', 'medium risk for hypotension', '2024-05-07 01:58:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor_details`
--
ALTER TABLE `doctor_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_details`
--
ALTER TABLE `patient_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctor_details`
--
ALTER TABLE `doctor_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `patient_details`
--
ALTER TABLE `patient_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
